#!/bin/bash

#debug

#This command can be used debug the file content and procedure " bash -x ./<filename> "
# example = " bash -x ./debug.sh "
# " set -x " is the starts exact point where you want to debug 
# " set +x " is the end exact point of the debug.


echo "vikas is here "
