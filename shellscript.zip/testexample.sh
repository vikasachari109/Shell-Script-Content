echo "hello world i am vikas" i am writing it again to append
